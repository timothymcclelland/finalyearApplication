To install my app run the APK 'app-debug.apk' within the Football Quiz first level folder.

Alternatively, open android studio and copy the (unzipped) football quiz folder into the android studio project folder and then within android studio open the file and run it. 